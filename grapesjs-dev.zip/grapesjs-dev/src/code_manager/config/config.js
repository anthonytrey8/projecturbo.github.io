export default {
  // Style prefix
  stylePrefix: 'cm-',

  inlineCss: false,
};
