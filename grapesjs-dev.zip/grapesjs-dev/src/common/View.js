export { View as default } from 'backbone';
