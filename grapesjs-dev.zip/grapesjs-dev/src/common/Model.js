export { Model as default } from 'backbone';
