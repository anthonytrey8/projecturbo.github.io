import { Collection } from '../../common';
import Category from './Category';

export default class Categories extends Collection {}

Categories.prototype.model = Category;
