import Backbone from 'backbone';
import ToolbarButton from './ToolbarButton';

export default Backbone.Collection.extend({ model: ToolbarButton });
