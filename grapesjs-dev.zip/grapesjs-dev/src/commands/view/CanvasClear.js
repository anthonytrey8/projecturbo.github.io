export default {
  run(ed) {
    ed.DomComponents.clear();
    ed.CssComposer.clear();
  },
};
