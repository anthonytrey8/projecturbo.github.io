import { Model } from '../../common';

export default class Command extends Model {
  defaults() {
    return {
      id: '',
    };
  }
}
