export default {
  // Style prefix
  stylePrefix: 'css-',

  // Default CSS style
  rules: [],
};
